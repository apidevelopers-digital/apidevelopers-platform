import { startOperationalGateway } from "./operational-server-runtime.mjs";
import { createOperationalRuntime } from "./operational-runtime.mjs";
import { startOperationalHttpServer } from "./operational-http-transport.mjs";
import { createWebAgentOperationalComposition } from "./web-agent-operational-composition.mjs";
import { attachTrustFaceAccessDurablePreviewToGateway } from "./trust-face-access-durable-runtime-transform.mjs";

function composeGatewayTransforms(starterTransform, externalTransform) {
  if (!starterTransform) return externalTransform;
  if (!externalTransform) return starterTransform;

  return (context = {}) => {
    const starterGateway = starterTransform(context);
    return externalTransform({
      ...context,
      gateway: starterGateway,
    });
  };
}

export async function startWebAgentOperationalGateway({
  env = process.env,
  cwd = process.cwd(),
  logger = console,
  gatewayStarter = startOperationalGateway,
  runtimeFactory = createOperationalRuntime,
  serverFactory = startOperationalHttpServer,
  webAgentFactory = createWebAgentOperationalComposition,
  gatewayTransform = attachTrustFaceAccessDurablePreviewToGateway,
  ...gatewayOptions
} = {}) {
  if (typeof gatewayStarter !== "function") {
    throw new TypeError("gatewayStarter must be a function");
  }
  if (typeof runtimeFactory !== "function") {
    throw new TypeError("runtimeFactory must be a function");
  }
  if (typeof serverFactory !== "function") {
    throw new TypeError("serverFactory must be a function");
  }
  if (typeof webAgentFactory !== "function") {
    throw new TypeError("webAgentFactory must be a function");
  }
  if (
    gatewayTransform !== undefined &&
    typeof gatewayTransform !== "function"
  ) {
    throw new TypeError("gatewayTransform must be a function");
  }

  let capturedRuntime;
  let webAgentDescriptor = Object.freeze({ enabled: false, mode: "shadow" });

  const capturingRuntimeFactory = (options = {}) => {
    const composedGatewayTransform = composeGatewayTransforms(
      options.gatewayTransform,
      gatewayTransform,
    );
    capturedRuntime = runtimeFactory({
      ...options,
      ...(composedGatewayTransform
        ? { gatewayTransform: composedGatewayTransform }
        : {}),
    });
    return capturedRuntime;
  };

  const wrappingServerFactory = async ({ app, host, port } = {}) => {
    if (!capturedRuntime?.store) {
      throw new TypeError("operational runtime store is unavailable");
    }
    const webAgent = webAgentFactory({
      app,
      store: capturedRuntime.store,
      env,
    });
    webAgentDescriptor = webAgent.descriptor;
    return serverFactory({
      app: webAgent.app,
      host,
      port,
    });
  };

  const started = await gatewayStarter({
    ...gatewayOptions,
    env,
    cwd,
    logger,
    runtimeFactory: capturingRuntimeFactory,
    serverFactory: wrappingServerFactory,
  });

  return Object.freeze({
    ...started,
    webAgent: webAgentDescriptor,
  });
}
