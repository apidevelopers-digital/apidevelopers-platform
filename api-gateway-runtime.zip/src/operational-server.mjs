import "./hostinger-entry.mjs";
