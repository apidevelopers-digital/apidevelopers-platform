import { registerOperationalShutdown } from "./operational-server-runtime.mjs";
import { resolveHostingerRuntimeEnv } from "./hostinger-runtime-env.mjs";
import { runUniCoPreviewBootstrap } from "./uni-co-preview-bootstrap.mjs";
import { startWebAgentOperationalGateway } from "./web-agent-operational-startup.mjs";

// Preserve the managed-hosting startup contract while routing the implementation
// through the Web Agent operational composition.
async function startOperationalGateway(options = {}) {
  return startWebAgentOperationalGateway(options);
}

const env = resolveHostingerRuntimeEnv(process.env);
const { server, runtime } = await startOperationalGateway({ env });
await runUniCoPreviewBootstrap({ app: runtime.app, env });

registerOperationalShutdown({ server });
